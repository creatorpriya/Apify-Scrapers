
import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $("div.mb-4.mt-6.flex.flex-col.gap-8.sm\\:mb-6.md\\:mb-5.lg\\:mb-8 > div").each((i, el) => {
            let reviewDate = $(el).find("div.mt-3.flex.flex-row.items-center.gap-6 > div > time").text();
            let reviewAuthor = $(el).find("div.flex.flex-row.items-center.gap-2 > a").text();
            let reviewTitle = $(el).find("div.flex.flex-row.sm\\:gap-2 > div:nth-child(1)").text() || $(el).find("div.flex.flex-row.gap-2 > p").text();
            let reviewDesc = $(el).find("div.styles_htmlText__eYPgj.text-18.font-normal.text-light-grey.italic.styles_format__8NeQe.styles_overallExperience__x7Gqf").text();
            let overAllRatings = $(el).find('div.flex.flex-row.mb-2 > div > label').length;
            const concatedString = 'checkId' + reviewDate + reviewDesc + reviewTitle + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                author: reviewAuthor,
                date: reviewDate,
                sourceCollector: 'producthunt.com',
                sourceUrl: request.url,
                title: reviewTitle,
                description: reviewDesc,
                ratings: overAllRatings,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

         let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'producthunt.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
       

        const infos = [];

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'producthunt.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(startUrls);

console.log('Crawler finished.');

await Actor.exit();