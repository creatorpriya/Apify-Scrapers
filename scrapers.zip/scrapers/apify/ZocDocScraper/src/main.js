

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
console.log('click review button');
const selectorToWaitDictionary = {
    "zocdoc.com": ".sc-qfqdbn-0.fGBgTC"
};
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });   
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
        
        const $ = cheerio.load(pageData);
        const data = [];
        
    $('[itemprop="reviews"]').each((i, el) => {
            console.log("review...", $('[itemprop="reviews"]').length);
               let reviewDate = $(el).find("span[itemprop='datePublished']").text().replace('Less than','');
               if(reviewDate.includes('days ago')){
                var datenum = reviewDate.replace(' days ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('A day ago')){
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('minutes ago')){
                var datenum = reviewDate.replace(' minutes ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * 1 * datenum * 60 * 1000)
            }else if(reviewDate.includes('hours ago')){
                var datenum = reviewDate.replace(' hours ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 60 * 1000)
            } else if (reviewDate.includes('months ago') || reviewDate.includes('1 month ago')) {
                 var datenum = reviewDate.replace(' months ago', '') || reviewDate.replace(' 1 month ago', '');
                 datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 30 * 24 * 60 * 60 * 1000);
            }else if (reviewDate.includes('More than 1 year ago')) {
                 reviewDate = new Date(Date.now() - 1 * 365 * 24 * 60 * 60 * 1000);  
            }else if (reviewDate.includes('1 year ago')) {
                 reviewDate = new Date(Date.now() - 1 * 365 * 24 * 60 * 60 * 1000);  
            }
               let reviewauthor = $(el).find("span[itemprop='name']").text();
               let reviewDesc = $(el).find("[data-test='regular-text-section']>span").text();
               let overallRatings = $(el).find("span[data-test='rating-display']").attr('aria-label').replace('Rated ','').replace(' out of 5 stars','');  //[data-test='stars-svg-wrapper']>svg
                 const concatedString = 'checkId' + reviewDate + reviewDesc + reviewauthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                date: reviewDate,
                author: reviewauthor,
                sourceCollector: 'zocdoc.com',
                sourceUrl: request.url,
                description: reviewDesc,
                ratings: overallRatings,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
       
        console.log('final adata-=-',JSON.stringify(data));
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'zocdoc.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);       
        
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'zocdoc.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();
