
//url: https://www.zomato.com/agra/pinch-of-spice-tajganj/reviews 

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();
const proxyConfiguration = await Actor.createProxyConfiguration();
/*
const proxyConfiguration = await Actor.createProxyConfiguration({
    // proxyUrls: [],
    // groups: ['RESIDENTIAL'],
    // countryCode: 'US'
});*/

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;
var failedCount = 0;

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

const crawler = new PuppeteerCrawler({
   proxyConfiguration,
    sessionPoolOptions: { maxPoolSize: 1 },
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks, log }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

            for(let i=1;i<10;i++){
                let num = i;
                if(i>1){
                    num = i+4;
                }
              
            }
            let sectionClass1 =  $(`#root > div > main > div > section:nth-child(5) > div > div > section > div:nth-child(3) > section:nth-child(1)`).attr("class");
            let divClass2 = $(`#root > div > main > div > section:nth-child(5) > div > div > section > div:nth-child(3) > div:nth-child(2)`).attr("class");
            let p = $(`#root > div > main > div > section:nth-child(5) > div > div > section > div:nth-child(3) > p`).attr("class");
            let divClass1 = $(`#root > div > main > div > section:nth-child(5) > div > div > section > div:nth-child(3) > div`).attr("class");
             
        $(`section[class="${sectionClass1}"]`).each((i, el) => {
            let reviewAuthor = $(el).find("div > div > a > p").text();
            data.push({author:reviewAuthor});
        });
    
        $(`div[class="${divClass2}"]`).each((i, el) => {
            let reviewDate = $(el).find("p").text();
            if(reviewDate.includes('days ago')){
                var datenum = reviewDate.replace(' days ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('A day ago')){
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('yesterday')){
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('minutes ago')){
                var datenum = reviewDate.replace(' minutes ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * 1 * datenum * 60 * 1000)
            }else if(reviewDate.includes('hours ago') || reviewDate.includes('an hour ago')){
                var datenum = reviewDate.replace(' hours ago','') || reviewDate.replace(' an hour ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 60 * 1000)
            } else if (reviewDate.includes('months ago')) {
                 var datenum = reviewDate.replace(' months ago', '');
                 datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 30 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('years ago')) {
                 var datenum = reviewDate.replace(' years ago', '');
                 datenum = parseInt(datenum);
                 reviewDate = new Date(Date.now() - datenum * 365 * 24 * 60 * 60 * 1000);    
            }
            data[i].date = reviewDate
        });

        $(`p[class="${p}"]`).each((i, el) => {
            let reviewDesc = $(el).text();
            data[i].description = reviewDesc
        });

        $(`div[class="${divClass1}"]`).each((i, el) => {
            let reviewRating = $(el).find("div > div:nth-child(1) > div > div > div").text().split("")[0]; 
            data[i].ratings = reviewRating
        });

        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data.map((item)=>{
            const concatedString = 'checkId' + item.date + item.description + item.author;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
                return {
                    ...item,
                    uniqueDocKey: uniqueEncodedKey,
                    sourceCollector: 'zomato.com',
                    sourceUrl: request.url,
                    checkId: urlMap[request.url].checkId,
                    accId: urlMap[request.url].accId
                }
            }),
            actorSource: 'zomato.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);

        const infos = [];

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
       if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'zomato.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();
