
// "url": "https://www.getapp.com/marketing-software/a/mailchimp/reviews/"

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const inputURLs = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
    //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];
        //const elements = document.querySelectorAll('.testimonial');
        let pageContent = $('#__NEXT_DATA__').text();
        console.log('pagedata=--=',typeof pageContent);
        let reviewJson = JSON.parse(pageContent);
        if(typeof reviewJson !== 'undefined' && reviewJson !== ''){
           // console.log('reviewJson.props-==-',reviewJson.props);
            reviewJson.props.pageProps.reviewsData.reviews.forEach((item) => {
                let content = '';
                if(typeof item.content !== 'undefined'){
                    content += `Content : ${item.content} \n`;
                }
                if(typeof item.pros !== 'undefined'){
                    content += `Pros : ${item.pros} \n`;
                }
                if(typeof item.cons !== 'undefined'){
                    content += `Cons : ${item.cons} \n`;
                }
                const concatedString = 'checkId' + content + item.title + new Date(item.created).toISOString();
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
                data.push({
                    author: item.user_info.full_name,
                    title: item.title,
                    sourceCollector: 'getapp.com',
                    sourceUrl: request.url,
                    description: content,
                    ratings: item.rating.total_rounded,
                    date: new Date(item.created).toISOString(),
                    "uniqueDocKey": uniqueEncodedKey,
                    checkId: urlMap[request.url].checkId,
                    accId: urlMap[request.url].accId
                });
            });
        }
      

        console.log('actor data-==-',JSON.stringify(data));

        let dataItems = [{
            "status": true,
            "message": "",            
            actorSource: 'getapp.com',
            "inputPayload": input,
            sourceURL: request.url,
            itemArray: data
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'getapp.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(startUrls);

console.log('Crawler finished.');

await Actor.exit();