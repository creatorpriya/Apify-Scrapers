
// https://www.indeed.com/cmp/Lockheed-Martin/reviews?fcountry=ALL

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

const proxyConfiguration = await Actor.createProxyConfiguration();

// const proxyConfiguration =  await Actor.createProxyConfiguration({
//     // proxyUrls: [],
//     groups: ['RESIDENTIAL'],
//     countryCode: 'US'
// });

const input = await Actor.getInput();

console.log('Input:');
console.dir(input);
const inputURLs = [];
var failedCount = 0;

const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

console.log('inputURLs-=-=', inputURLs);

const crawler = new PuppeteerCrawler({
    proxyConfiguration,
    sessionPoolOptions: { maxPoolSize: 1 },
    maxRequestsPerCrawl: 50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        );
        const $ = cheerio.load(pageData);
        if(typeof $('.gnav-mq5q72.eu4oa1w0') !== 'undefined'){
            $('.gnav-mq5q72.eu4oa1w0').remove();
        }

        await page.waitForTimeout(1000);
        const data = [];
        let errormessage = '';

        $('[data-tn-entitytype="reviewId"]').each(async (i, el) => {
            console.log('inside each');
            const title = $(el).find(`[data-testid="titleLink"]`).text();
            console.log('title-=-=', title);
            const ratings = $(el).find(".css-1c33izo.e1wnkr790").text();
            // const dateAndJobRole = $(el)
            //     .find('[itemprop="author"]')
            //     .text()
            //     ?.split(" - ");
            const description_main = $(el).find('[itemprop="reviewBody"]').text();
            const description_prosAndCons = $(el).find(".css-1z0411s.e1wnkr790").text();
            const author = $(el)
                .find('[itemprop="author"]')
                .text();                      //dateAndJobRole[2];
            const dateText = $(el)
                .find('[itemprop="author"]')
                .text();
            var reviewUrl = $(el)
                .find(`[data-tn-element="individualReviewLink"]`)
                .attr("href");

            var description;
            if (description_prosAndCons !== "")
                description = description_main + description_prosAndCons;
            else description = description_main;

            const concatedString = 'checkId' + dateText + description + title + author;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            reviewUrl = "https://indeed.com" + reviewUrl;
            let pattern = / - [A-Za-z]+ \d+, \d{4}/;
            const regex = /(?:January|February|March|April|May|June|July|August|September|October|November|December)\s\d{1,2},\s\d{4}/;
            const match = dateText.match(regex);

            data.push({
                title: title,
                ratings: parseFloat(ratings),
                author: author.replace(pattern, ''),
                date: match,
                description: description,
                reviewUrl: reviewUrl,
                uniqueDocKey: uniqueEncodedKey,
                sourceCollector: 'indeed.com',
                sourceURL: request.url,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        
        console.log(`total records---${data.length}`);
        console.log(JSON.stringify(data));
        if(data.length === 0){
            errormessage = 'Unable to extract data';
        }else {
             errormessage = '';
        }
        let dataItems = [{
            "status": true,
            "message": errormessage, 
            "inputPayload": input,           
            actorSource: 'indeed.com',
            sourceURL: request.url,
            itemArray: data
        }];
        await Actor.pushData(dataItems);
          //  await Actor.exit();

    },
    async failedRequestHandler({ request }) {
        
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'indeed.com',
            "sourceURL": request.url,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
        }];
        await Actor.pushData(dataItems);
           // await Actor.exit();
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

// Exit successfully
await Actor.exit();
