import { Dataset, createPuppeteerRouter } from 'crawlee';
import cheerio from "cheerio";
export const router = createPuppeteerRouter();
console.log('get router--==-',router);
var pageNum = 0
router.addDefaultHandler(async ({ enqueueLinks, log }) => {
    log.info(`enqueueing new URLs-==-`,pageNum);
    if(pageNum < 3){
    await enqueueLinks({
       // globs: ['https://www.indeed.com/cmp/Lockheed-Martin/reviews?start=*'],
        label: 'detail',
        selector:'.cmp-ReviewsList'
    });
  }
    pageNum++;
    //console.log('increase page-==--',pageNum);
    //if (infos.length === 0) console.log(`On last page!`);
});

router.addHandler('detail', async ({ request, page, log }) => {
    const title = await page.title();
    //log.info(`${title}`, { url: request.loadedUrl });
    console.log('check data',title);
    console.log('check page--==-',page);
    var pageData = await page.evaluate(
                () => document.querySelector("*").outerHTML
            );
    const $ = cheerio.load(pageData);
        const reviewsArr = [];
    $('[data-tn-entitytype="reviewId"]').each( async (i, el) => {
      console.log('inside each');
      const title = $(el).find(`[data-testid="titleLink"]`).text();
      console.log('title-=-=',title);
      const ratings = $(el).find(".css-1c33izo.e1wnkr790").text();
      const dateAndJobRole = $(el)
        .find('[itemprop="author"]')
        .text()
        ?.split(" - ");
      const description_main = $(el).find('[itemprop="reviewBody"]').text();
      const description_prosAndCons = $(el).find(".css-1z0411s.e1wnkr790").text();
      const date = dateAndJobRole[2];
      const author = dateAndJobRole[0];
      var reviewUrl = $(el)
        .find(`[data-tn-element="individualReviewLink"]`)
        .attr("href");

      var description;
      if (description_prosAndCons !== "")
        description = description_main + description_prosAndCons;
      else description = description_main;

      const concatedString = 'checkId' + reviewUrl + date;
      const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
      reviewUrl = "https://indeed.com" + reviewUrl;

      await Dataset.pushData({
        title: title,
        ratings: parseFloat(ratings),
        author: author,
        "date": (!Number.isNaN(new Date(date).getTime()))?new Date(date).toISOString():new Date().toISOString(),
        description: description,
        reviewUrl: reviewUrl,
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'indeed.com',
        sourceURL:request.url
      });
    });
    /*await Dataset.pushData({
        url: request.loadedUrl,
        title,
    });*/
});
