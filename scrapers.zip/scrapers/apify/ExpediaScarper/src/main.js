
// url: "https://www.expedia.com/Tokyo-Hotels-APA-Hotel-Resort-Nishishinjuku-Gochome-Eki-Tower.h20412136.Hotel-Information?pwaDialog=summary-reviews-property-summary-1"

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
    console.log('click more button');
  const selectorToWaitDictionary = {
    "expedia.com": "[id='app-blossom-flex-ui']"
    
 };
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });   
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
         
      
        console.log('Move to review page');
        await page.click('button.uitk-link-medium');
        // await page.click('span.yJaSJ'); //[data-name="user-reviews"] 
        await waitForPageToLoad('expedia.com', page);
        
        await new Promise(resolve => setTimeout(resolve, 1000));
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
         var totalreview = await page.evaluate(
             () => document.querySelector('.uitk-card-content-section.uitk-card-content-section-border-block-end.uitk-card-content-section-padded')
         );
        const $ = cheerio.load(pageData);
        const data = [];
        console.log('total review-=-=0',$('.uitk-card-content-section.uitk-card-content-section-border-block-end.uitk-card-content-section-padded').length);
        $('.uitk-card-content-section.uitk-card-content-section-border-block-end.uitk-card-content-section-padded').each((i, el) => {
            let reviewAuthor = $(el).find("Section>h4").text();
            let reviewDate = $(el).find("[itemprop='datePublished']").text();
            let reviewDesc = $(el).find("span[itemprop='description']").text();
            let overallRatings = $(el).find("Section>h3>span").text().split("/")[0]; 
            const concatedString = 'checkId' + reviewDesc + reviewDate + overallRatings + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                author: reviewAuthor,
                date: reviewDate,
                sourceCollector: 'expedia.com',
                sourceUrl: request.url,
                description: reviewDesc,
                uniqueDocKey: uniqueEncodedKey,
                ratings: overallRatings,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId,
            });
        });
        
        if(data.length === 0){
            errorMessage = 'Unable to extract data from HTML';
        }else {
            errorMessage = '';
        }
        // Store the results to the default dataset.
        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            actorSource: 'expedia.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);

        // Find a link to the next page and enqueue it if it exists.
        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);
       
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'expedia.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURLs);

console.log('Crawler finished.');

// Exit successfully
await Actor.exit();