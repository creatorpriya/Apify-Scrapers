
import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const urlMap = {};
const inputURLs = [];

const proxyConfiguration = await Actor.createProxyConfiguration({
    groups: ['RESIDENTIAL'],
    countryCode: 'US'
  });

for(let i=0;i<input.startUrls.length;i++){
   
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
   proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
    
    proxyConfiguration,
    async requestHandler({ request, page, enqueueLinks, log }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];
        

         $("[data-test-target='HR_CC_CARD']").each((i, el) => {
        console.log("review...", $("[data-test-target='HR_CC_CARD']").length);
    const ratings = $(el).find("div.kmMXA._T.Gi > div.WcRsW.f.O > div > svg > title").text();
        console.log('ratings-=--=', ratings);
    const description = $(el).find('.fIrGe._T>span>span').text();
    const datetext = $(el).find("span.iSNGb._R.Me.S4.H3.Cj").text();
    const author = $(el).find('div.ScwkD._Z.o.S4.H3.Ci>span>a').text();
    var reviewUrl = $(el).find(`[data-test-target="review-title"]`).find(`a`).attr("href");
    const title = $(el).find('[data-test-target="review-title"]>a>span>span').text();
    const concatedString = 'checkId' + reviewUrl + datetext + title + description + author;
    const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
    console.log('datetext--=-=', datetext);

    data.push({
        title: title,
        ratings: ratings.replace(' of 5 bubbles', ''),
        author: author,
        reviewUrl: `https://www.tripadvisor.com${reviewUrl}`,
        date: datetext ? datetext.replace('Date of stay: ', '') : '',
        description: description,
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'tripadvisor.com',
        sourceURL:request.url,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
    });
  });
         

       let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'capterra.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        
        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
       if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'capterra.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);


console.log('Crawler finished.');

await Actor.exit();
