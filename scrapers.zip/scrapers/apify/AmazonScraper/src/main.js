
// https://www.amazon.com/dp/B08G59N69N/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B08G59N69N&pd_rd_w=GUFN9&content-id=amzn1.sym.eb7c1ac5-7c51-4df5-ba34-ca810f1f119a&pf_rd_p=eb7c1ac5-7c51-4df5-ba34-ca810f1f119a&pf_rd_r=SPPZ1ZTMWFGV0S1159T9&pd_rd_wg=arop9&pd_rd_r=dcf38229-8d0b-4fd7-a6d9-97b60eaad0e2&s=hpc&sp_csd=d2lkZ2V0TmFtZT1zcF9kZXRhaWw

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
console.log('click review button');
const selectorToWaitDictionary = {
    "amazon.com": ".a-spacing-extra-large"
};
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });   
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
        
        const $ = cheerio.load(pageData);
        const data = [];
        
        $('.review-views .a-section.review').each((i, el) => {
    var ratings = $(el).find('.review-rating .a-icon-alt').text().replace(' out of 5 stars','');
        console.log('ratings-=--=',ratings);
    const description = $(el).find(".review-text-content").text();
    const datetext = $(el).find(".review-date").text();
    const author = $(el).find('.a-profile-content').text();
    var reviewUrl = $(el).find('.review-title-content').attr("href");
    const title = $(el).find('.review-title-content span:not(.a-icon-alt):not(.a-letter-space)').text();

    const concatedString = 'checkId' + description + datetext + title;
    const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
    
    data.push({
        title: title,
      ratings: parseFloat(ratings),
        author: author,
        reviewUrl: `https://www.amazon.com/${reviewUrl}`,
        date: datetext, 
        description: description.replace(/\n/g,''),
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'amazon.com',
        sourceURL:request.url,
        checkId: urlMap[request.url].checkId,
        accId: urlMap[request.url].accId
    });
  });
       
        console.log('final adata-=-',JSON.stringify(data));
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'amazon.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);       
        
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'amazon.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();
