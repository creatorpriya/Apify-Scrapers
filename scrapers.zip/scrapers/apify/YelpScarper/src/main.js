
import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const proxyConfiguration = await Actor.createProxyConfiguration();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
const inputURLs = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

console.log('inputURLs-=-=',inputURLs);
var failedCount = 0;

const crawler = new PuppeteerCrawler({
    proxyConfiguration,
    sessionPoolOptions: { maxPoolSize: 1 },
    launchContext: {
        launchOptions: {
            headless: true,
        },
    },

    maxRequestsPerCrawl: 50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log('Processing ...',request);
        var pageData = await page.evaluate(
                () => document.querySelector("*").outerHTML
            );
        // let data = [];
        const $ = cheerio.load(pageData);
        const data = [];
       // console.log('$=-=-=0',pageData);
        
        $('#reviews ul.list__09f24__ynIEd li').each((i, el) => {
    //const title = $(el).find(`[data-testid="titleLink"]`).text();
    var ratings = $(el).find('.css-14g69b3').attr("aria-label");
        console.log('ratings-=--=',ratings);
        // ratings = ratings?.[0] || 0;
    const description = $(el)
        .find(".raw__09f24__T4Ezm")
        .children()
        .remove()
        .end()
        .text();
    const datetext = $(el).find("div.arrange-unit__09f24__rqHTg.arrange-unit-fill__09f24__CUubG.css-1qn0b6x > span.css-chan6m").text();
    const author = $(el).find('span[class="fs-block css-ux5mu6"]').text();
    var reviewUrlData = $(`[class=" display--inline__09f24__c6N_k border-color--default__09f24__NPAKY"]`).find(`a`)
    .attr("href");
  const reviewUrl = reviewUrlData?.split("=")[1];


    const concatedString = 'checkId' + reviewUrl + datetext + description + author;
    const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
   // reviewUrl = "https://indeed.com" + reviewUrl;

    data.push({
        ratings: parseFloat(ratings),
        author: author,
        reviewUrl: reviewUrl,
        date: datetext,
        description: description,
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'yelp.com',
        sourceURL:request.url,
        checkId: urlMap[request.url].checkId,
        accId: urlMap[request.url].accId,
    });
  });
       
        console.log('final adata-=-',JSON.stringify(data));
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            actorSource: 'yelp.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
       // const webhookUrl = 'https://dyii1vumbh.execute-api.us-east-1.amazonaws.com/dev/insertapifydata';
        /*const response = await utils.requestAsBrowser({
            url: webhookUrl,
            method: 'POST',
            payload: dataItems,
        });*/
        await Actor.pushData(dataItems);
      //  await Actor.exit();

        // Find a link to the next page and enqueue it if it exists.
        const infos = await enqueueLinks({
            selector: '.pagination-links__09f24__bmFj8 .pagination-link-container__09f24__RAlwO',
        });

        if (infos.length === 0) console.log(`${request} is the last page!`);
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'yelp.com',
            "sourceURL": request.url,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId,
                "inputPayload": input
        }];
        
        await Actor.pushData(dataItems);
      //  await Actor.exit();
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURLs);

console.log('Crawler finished.');

// Exit successfully
await Actor.exit();
