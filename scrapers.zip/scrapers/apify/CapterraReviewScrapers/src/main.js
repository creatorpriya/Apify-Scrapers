
import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const urlMap = {};
const inputURLs = [];

const proxyConfiguration = await Actor.createProxyConfiguration({
    groups: ['RESIDENTIAL'],
    countryCode: 'US'
  });

for(let i=0;i<input.startUrls.length;i++){
   
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
   proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
    
    proxyConfiguration,
    async requestHandler({ request, page, enqueueLinks, log }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];
         console.log('reviews-=-=-=',$('[data-testid="review-card"]'));   
        if($('[data-testid="review-card"]') !== null && $('[data-testid="review-card"]').length > 0){
            $('[data-testid="review-card"]').each((i, el) => {
            let reviewAuthor = $(el).find("div.flex.items-center.gap-xs > div.flex.flex-col > div.text-lg.leading-lg").text();
            let reviewDate = $(el).find("div.mt-auto.text-sm.text-neutral-80.w-full > div:nth-child(3)").text();
            let reviewTitle = $(el).find(".bg-success-10.p-2xs.flex-1 > p.whitespace-pre-line.text-md.leading-md").text();
            let reviewDesc = $(el).find("div > div:nth-child(4) > p > span:nth-child(2)").text();
            let overallRatings = $(el).find("dd:nth-child(2) > div > span").text();
            const concatedString = 'checkId' + reviewDate + reviewDesc + reviewAuthor + reviewTitle;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");

            data.push({
                author: reviewAuthor,
                title: reviewTitle,
                date: reviewDate,
                description: reviewDesc,
                ratings: overallRatings,
                sourceCollector: 'capterra.com',
                sourceUrl: request.url,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        }else {
            $('[data-test-id="review-card"]').each((i, el) => {
            let reviewAuthor = $(el).find('[data-testid="reviewer-full-name"]').text();
            let reviewDate = $(el).find('[data-testid="review-written-on"]').text();
            let reviewTitle = $(el).find('[data-testid="review-content"] .text-lg').text();
            let reviewDesc = `${$(el).find('[data-testid="overall-content"]').text()} \n 
            ${$(el).find('[data-testid="pros-content"]').text()} \n 
            ${$(el).find('[data-testid="cons-content"]').text()}` ;
            let overallRatings = $(el).find('[data-testid="Overall Rating-rating"] .star-rating-label').text();
            const concatedString = 'checkId' + reviewDate + reviewDesc + reviewAuthor + reviewTitle;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");

            data.push({
                author: reviewAuthor,
                title: reviewTitle,
                date: reviewDate,
                description: reviewDesc,
                ratings: overallRatings,
                sourceCollector: 'capterra.com',
                sourceUrl: request.url,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        }

         

       let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'capterra.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        
        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
       if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'capterra.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);


console.log('Crawler finished.');

await Actor.exit();
