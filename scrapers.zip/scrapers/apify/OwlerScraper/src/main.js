
import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

var failedCount = 0;
const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;
const inputURLs = [];
const urlMap = {};

// const proxyConfiguration = await Actor.createProxyConfiguration({
//   });

for (let i = 0; i < input.startUrls.length; i++) {
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url] = input.startUrls[i].entityId;
}

const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 5,

    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        );

        let content = await page.evaluate(
            () => document.querySelector("#__NEXT_DATA__").innerHTML
        );

        const $ = cheerio.load(pageData);
        console.log('data=-=-=-',content);
        const data = [];
        let errorMessage = '';
        let {
            companyId,
            companyName,
            description,
            shortName,
            domainName,
            teamName,
            logo,
            founded,
            ownership,
            revenue,
            employeeCount,
            industrySectors,
            links,
            ceoDetail,
            city,
            state,
            country,
            statusInfo,
            exchange,
            ticker,
            street1Address,
            zipcode,
            phoneNumber,
            totalAcquisitions,
            summarySection,
            formattedFunding,
            DMACode,
            sicCode,
            website,
            industries,
            investmentCount,
            acquisitionCount
        } = JSON.parse(content).props.initialState;

        
            data.push({
            companyId,
            companyName,
            description,
            shortName,
            domainName,
            teamName,
            logo,
            founded,
            ownership,
            revenue,
            employeeCount,
            industrySectors,
            links,
            ceoDetail,
            city,
            state,
            country,
            statusInfo,
            exchange,
            ticker,
            street1Address,
            zipcode,
            phoneNumber,
            totalAcquisitions,
            summarySection,
            formattedFunding,
            DMACode,
            sicCode,
            website,
            industries,
            investmentCount,
            acquisitionCount,
            owlerUrl: request.url,
                companyId: urlMap[request.url]
        });
     /*   
        */
/*

        $('div.content-container.flex').each((i, el) => {
            let companyName = $(el).find("div.competitors-v2_wrapper__y1XU7 > h3 > a").text();
            companyName = companyName.replace(' Competitors', '');
            let companyCEO = $(el).find("p.ceo-block_name__j_5ZW.CP").text();
            let companyCEOlinkdinpageURL = $(el).find("div.ceo-block_boxOne__ubr2e.CP > div > div > a").attr("href");
            let companyFounded = $(el).find("[itemprop='foundingDate']").text();
            let companyRatings = $(el).find("p.block.ceo-block_ratingText__Nfimj.CP.styled-text.black").text();
            let companyCity = $(el).find("[itemprop='addressLocality'] a.overview_deeplink__uI9h6.link.primary:nth-child(1)").text();
            let companyState = $(el).find("[itemprop='addressLocality'] a.overview_deeplink__uI9h6.link.primary:nth-child(3)").text();
            let companyLocation = `${companyCity}, ${companyState}`;
            let companyStatus1 = $(el).find("div.overview_right__gmZSe.overview_block___U0F6 > p > a").text();
            let companyStatus2 = $(el).find("p > span:nth-child(2)").text();
            let companyStatus3 = $(el).find("p > span:nth-child(3)").text();
            let companyStatus4 = $(el).find("p > span:nth-child(4)").text();
            let companyStatus = `${companyStatus1}, ${companyStatus2}, ${companyStatus3}, ${companyStatus4}`;
            let companyInduatry = $(el).find("div:nth-child(5) > div.overview_right__gmZSe.overview_block___U0F6 > a").text();
            let companySector = $(el).find("div:nth-child(6) > div.overview_right__gmZSe.overview_block___U0F6 > a").text();
            let company_SIC_Code = $(el).find("div:nth-child(7) > div.overview_right__gmZSe.overview_block___U0F6").text();
            let companyWebsite = $(el).find("div:nth-child(8) > div.overview_right__gmZSe.overview_block___U0F6 > div > p > a").text();
            let companyfacebookpageURL = $(el).find("div:nth-child(9) > div.overview_right__gmZSe.overview_block___U0F6 > div > a:nth-child(1)").attr("href");
            let companytwitterpageURL = $(el).find("div:nth-child(9) > div.overview_right__gmZSe.overview_block___U0F6 > div > a:nth-child(2)").attr("href");
            let companylinkdinpageURL = $(el).find("div:nth-child(9) > div.overview_right__gmZSe.overview_block___U0F6 > div > a:nth-child(3)").attr("href");
            let companyAnnualRevenue = $(el).find("div.data-contacpLimitExceediner.flex > div").text();
            let companyEmployees = $(el).find("div.count-container.EMPLOYEE_EXACT.CP.botifyemployeedata").text();
            let companyFunding = $(el).find("a:nth-child(4) > div.section-data").text();
            let companyAcquisitions = $(el).find("a:nth-child(5) > div.section-data").text();
            let companyInvestments = $(el).find("a:nth-child(6) > div.section-data").text();
            const concatedString = 'checkId' + companyName + companyCEO + companyLocation + companyFounded + companyAnnualRevenue + companyEmployees;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");

            data.push({
                company_Name: companyName,
                company_CEO: companyCEO,
                company_CEO_Linkdin_Page_URL: companyCEOlinkdinpageURL,
                company_Founded: companyFounded,
                company_Ratings: companyRatings,
                company_Location: companyLocation,
                company_Status: companyStatus,
                company_Induatry: companyInduatry,
                company_Sector: companySector,
                company_SIC_Code: company_SIC_Code,
                company_Website: companyWebsite,
                company_Facebook_Page_URL: companyfacebookpageURL,
                company_Twitter_Page_URL: companytwitterpageURL,
                company_Linkdin_Page_URL: companylinkdinpageURL,
                company_Annual_Revenue: companyAnnualRevenue,
                company_Employees: companyEmployees,
                company_Funding: companyFunding,
                company_Acquisitions: companyAcquisitions,
                company_Investments: companyInvestments,
                sourceCollector: 'owler.com',
                owlerUrl: request.url,
                "uniqueDocKey": uniqueEncodedKey,
                companyId: urlMap[request.url]
            });
        });
*/

        if (data.length === 0) {
            errorMessage = "Unable to extract data from HTML";
        } else {
            errorMessage = "";
        }

        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'owler.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];


        if (infos.length === 0) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if (failedCount > 2) {
            let dataItems = [{
                "status": false,
                "message": "403",
                itemArray: [],
                actorSource: 'owler.com',
                "sourceURL": request.url,
                "inputPayload": input,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            }];

            await Actor.pushData(dataItems);
        }


        failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();