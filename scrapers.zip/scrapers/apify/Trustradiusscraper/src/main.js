/**
 * This template is a production ready boilerplate for developing with `PuppeteerCrawler`.
 * Use this to bootstrap your projects using the most up-to-date code.
 * If you're looking for examples or want to learn more, see README.
 */

// For more information, see https://sdk.apify.com
import { Actor } from 'apify';
// For more information, see https://crawlee.dev
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";

await Actor.init();

// Create an instance of the PuppeteerCrawler class - a crawler
// that automatically loads the URLs in headless Chrome / Puppeteer.
const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
    // Here you can set options that are passed to the launchPuppeteer() function.
    launchContext: {
        launchOptions: {
            headless: true,
            // Other Puppeteer options
        },
    },

    // Stop crawling after several pages
    maxRequestsPerCrawl: 50,

    // This function will be called for each URL to crawl.
    // Here you can write the Puppeteer scripts you are familiar with,
    // with the exception that browsers and pages are automatically managed by the Apify SDK.
    // The function accepts a single parameter, which is an object with the following fields:
    // - request: an instance of the Request class with information such as URL and HTTP method
    // - page: Puppeteer's Page object (see https://pptr.dev/#show=api-class-page)
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request.url}...`);
        var requestURL = request.url;
        // A function to be evaluated by Puppeteer within the browser context.
        var pageData = await page.evaluate(
                () => document.querySelector("*").outerHTML
            );
        
        const $ = cheerio.load(pageData);
        const data = [];

        $('div[class^="ProductReviews_reviews-body__"] [class^="Review_review__"]').each((i,el) => {
            let title = $(el).find('header h4').text();
            console.log('title=--=',title);
            let overall_ratings = $(el).find('span[class^="ReviewScore_score-value_"]').text();
            let author = $(el).find('.nb-flex-grow div[class="nb-flex nb-mb-xl"] div[class="nb-flex nb-text-lg nb-items-center nb-mb-3xs"]').text();
            let date = $(el).find('[class^="Review_date__"]').text();
            let description = $(el).find('[class^="Review_body__"]').text();
            let concatedString = author + title + date + description;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            let reviewUrl = $(el).find('[class^="Review_heading__"] a').prop('href');
           data.push({
                title: title,
                    ratings: (overall_ratings !== '') ? parseInt(overall_ratings.replace(' out of 10', '')) : 0,
                    author: author,
                    date: date,
                    description: description,
                    uniqueDocKey: uniqueEncodedKey,
                    reviewUrl: reviewUrl,
                    sourceCollector: "trustradius.com",
                    sourceURL:request.url,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        
        console.log(JSON.stringify(data));
        // Store the results to the default dataset.
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            actorSource: 'trustradius.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);

        // Find a link to the next page and enqueue it if it exists.
        const infos = await enqueueLinks({
            selector: '.PageItem_page-item__3eySE.page-item',
        });

        if (infos.length === 0) console.log(`${request.url} is the last page!`);
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'trustradius.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
        
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURLs);

console.log('Crawler finished.');

// Exit successfully
await Actor.exit();
