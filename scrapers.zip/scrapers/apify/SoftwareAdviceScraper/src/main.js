
// https://www.softwareadvice.com/accounting/docyt-profile/reviews/

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

var failedCount = 0;
const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;
const inputURLs= [];
const urlMap = {};

// const proxyConfiguration = await Actor.createProxyConfiguration({
//   });

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};  
}

const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 5,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];
        let errorMessage = '';

        $('[data-testid="ReviewsListComponent"]').each((i, el) => {
            let reviewDate = $(el).find("[data-testid='reviewed-date']").text().replace("Reviewed ", "");
            let reviewAuthor = $(el).find("[data-testid='reviewer-first-name']").text();
            let reviewTitle = $(el).find("[data-testid='reviewer-industry']").text();
            let reviewRating = $(el).find("div:nth-child(1) > div > [data-testid='review-overall-rating-value']").text();
            let reviewDesc = $(el).find("p[data-testid='overall-summary']").text();
            let reviewPros = $(el).find("p[data-testid='review-pros-content']").text();
            let reviewCons = $(el).find("p[data-testid='review-cons-content']").text();
            const concatedString = 'checkId' + reviewDate + reviewDesc + reviewAuthor + reviewTitle + reviewPros + reviewCons
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");

            data.push({
                date: reviewDate,
                author: reviewAuthor,
                title: reviewTitle,
                description: `${reviewDesc} \n ${reviewPros} \n ${reviewCons}`,
                ratings: reviewRating,
                sourceCollector: 'softwareadvice.com',
                sourceUrl: request.url,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });


        if(data.length === 0){
            errorMessage = "Unable to extract data from HTML";
        }else {
            errorMessage = "";
        }

        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'softwareadvice.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
    

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
         console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'softwareadvice.com',
            "sourceURL": request.url,
            "inputPayload": input,
            checkId: urlMap[request.url].checkId,
            accId: urlMap[request.url].accId
        }];
        
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(startUrls);

console.log('Crawler finished.');

await Actor.exit();