
// https://play.google.com/store/apps/details?id=com.spoken.app&hl=en_US&gl=US&pli=1


import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

var failedCount = 0;
const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks, log }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        await page.waitForTimeout(1000);
        await page.click("button[jscontroller='soHxf']");

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        let title =  await page.evaluate(
            () => document.querySelector("title").innerText
        );

        console.log(title);

        // let tabActive =  await page.evaluate(
        //     () => document.getElementById("ZCHFDb").hasAttribute("aria-hidden")
        // );

        // if (tabActive === false){
        //     await page.waitForTimeout(1000);
        // }

        const $ = cheerio.load(pageData);
        const data = [];
        let errorMessage = '';
        $(".EGFGHd").each((i, el) => {
            let reviewDate = $(el).find("span.bp9Aid").text();
            let reviewAuthor = $(el).find("div.X5PpBb").text();
            let reviewDesc = $(el).find(".h3YV2d").text();
            let overallRatings = $(el).find(".iXRFPc").attr("aria-label").replace('Rated ', '').replace(' stars out of five stars', '');  //split(" ")[1]
            
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
           
            data.push({
                author: reviewAuthor,
                date: reviewDate,
                sourceCollector: 'play.google.com',
                sourceURL: request.url,
                description: reviewDesc,
                ratings: overallRatings,
                uniqueDocKey: uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

        if(data.length === 0){
            errorMessage = "Unable to extract data from HTML";
        }else {
            errorMessage = "";
        }

        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'play.google.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
           // await Actor.exit();

         const infos = [];/*await enqueueLinks({
             selector: '.u4ICaf button.VfPpkd-LgbsSe',
         });*/

        
         if ( infos.length === 0 ) console.log(`${request} is the last page.`)
         if(data.length > 0){
            //await Actor.exit();
         }
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            "inputPayload": input,
            itemArray: [],
            actorSource: 'play.google.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
            //await Actor.exit();
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);
console.log('Crawler finished.');

// Exit successfully
await Actor.exit();
