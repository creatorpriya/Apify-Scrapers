
// "url": "https://www.ratemds.com/doctor-ratings/588735/Dr-Timothy+J.-Weibel-San+Jose-CA.html/"

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const proxyConfiguration = await Actor.createProxyConfiguration();

var failedCount = 0;
const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
const inputURL = [];

const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURL.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

const crawler = new PuppeteerCrawler({
   proxyConfiguration,
    sessionPoolOptions: { maxPoolSize: 1 },
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    //proxyConfiguration,
    async requestHandler({ request, page }) {
        console.log(`Processing ${request}...`);
         console.log('New page created');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
    
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
         var totalreview = await page.evaluate(
             () => window.DATA.doctorDetailProps
         );

        const $ = cheerio.load(pageData);
        const data = [];
         totalreview.ratingsPage.results.forEach((item) => {  
             const concatedString = 'checkId' + item.created + item.comment;
             const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");

            data.push({
                date: item.created,
                description:item.comment,
                ratings: item.average,
                sourceCollector: 'ratemds.com',
                sourceUrl: request.url,
                 "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        

        // Store the results to the default dataset.
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'ratemds.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        // Find a link to the next page and enqueue it if it exists.
        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);
       
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'ratemds.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURL);

console.log('Crawler finished');

// Exit successfully
await Actor.exit();


