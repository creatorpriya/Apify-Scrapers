import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';
import axios from 'axios';
const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();
const proxyConfiguration = await Actor.createProxyConfiguration();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
   proxyConfiguration,
    sessionPoolOptions: { maxPoolSize: 1 },
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 5,
    
    async requestHandler({ request, page, enqueueLinks, log }) {
        let urlParams = new URL(request.url);
        let reviewData = await axios.get(`https://api.appexchange.salesforce.com/services/apexrest/reviews?listingId=${urlParams.searchParams.get("listingId")}&pageLength=10&pageNumber=1`);

        console.log(`Scraping...`);
        console.log('New page created')
        console.log('reviewData-=-==-',reviewData.data.reviews);
        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        reviewData.data.reviews.forEach((item) => {
            data.push({
                date: item.reviewDate,
                author: item.user.name,
                sourceCollector: 'appexchange.salesforce.com',
                sourceUrl: request.url,
                title: item.questionResponses[1].response,
                description: item.questionResponses[2].response,
                ratings: item.rating,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

       let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            actorSource: 'appexchange.salesforce.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);

        const infos = [];

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
       if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'appexchange.salesforce.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();