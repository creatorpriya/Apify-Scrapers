
// url: "https://www.google.com/search?q=iphone+14&rlz=1C1VDKB_enIN1066IN1066&oq=i&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDsyBggCEEUYOzINCAMQABiDARixAxiABDIGCAQQRRg8MgYIBRBFGDwyBggGEEUYPDIGCAcQRRg80gEIMjU4MWowajeoAgCwAgA&sourceid=chrome&ie=UTF-8"

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
//const inputURL = [];

const inputURL = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURL.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
    console.log('click more button');
  const selectorToWaitDictionary = {
    "google.com": ".M5YwGc"
    
 };
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });    
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
         
      
        console.log('Move to google page');
        await page.click("[data-attrid='kc:/shopping/gpc:reviews-modal'] > .J8Ur2b > .FNYAy > button > span.Cs2GTd");
        // await page.click('span.yJaSJ'); //[data-name="user-reviews"] 
        await waitForPageToLoad('google.com', page);
        
        await new Promise(resolve => setTimeout(resolve, 1000));
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
         var totalreview = await page.evaluate(
             () => document.querySelector('.HDso9d[aria-label="User review"]')
         );
        const $ = cheerio.load(pageData);
        const data = [];
        console.log('total review-=-=0',$('.HDso9d[aria-label="User review"]').length);
        $('.HDso9d[aria-label="User review"]').each((i, el) => {
            let d = new Date();
            let reviewTime = $(el).find(".TqzWd .C8sUec").text();
            let author = $(el).find(".TqzWd .q7ToWe").text();
            let rating = $(el).find(".TqzWd .z3HNkc").attr('aria-label').replace('Rated ','').replace(' out of 5,','');
            let reviewTitle = $(el).find(".KTsGge").text();
            let reviewDesc = $(el).find(".YKsAwb").text();
            
            if(reviewTime.includes('months ago')){
                d.setMonth(d.getMonth() - parseInt(reviewTime.replace(' months ago')))
            }
            const concatedString = 'checkId' + reviewDesc + author + reviewTitle;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            let errorMessage = '';
            data.push({
                date: d.toISOString(),
                sourceCollector: 'google.com',
                sourceUrl: request.url,
                title: reviewTitle,
                description: reviewDesc,
                author: author,
                ratings: parseInt(rating),
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId

            });
        });
        
        if(data.length === 0){
            errorMessage = 'Unable to extract data from HTML';
        }else {
            errorMessage = '';
        }
        // Store the results to the default dataset.
        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'google.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        // Find a link to the next page and enqueue it if it exists.
        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);
       
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'google.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURL);

console.log('Crawler finished.');

// Exit successfully
await Actor.exit();