
// https://www.healthgrades.com/physician/dr-curtiss-combs-yflyr#reviews

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();
/*
const proxyConfiguration = await Actor.createProxyConfiguration({
    // proxyUrls: [],
    groups: ['RESIDENTIAL'],
    countryCode: 'US'
});*/

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
    //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $('.l-single-comment-container').each((i, el) => {
            let reviewDate = $(el).find(".c-single-comment__commenter-info").text();
            let reviewDesc = $(el).find(".c-single-comment__comment").contents().last().text();
            let reviewtitle = $(el).find(".c-single-comment__title.c-single-comment__overview__item").text();
            let overallRatings = $(el).find('.c-single-comment__summary [role="img"]').attr('aria-label');
            const concatedString = 'checkId' + reviewDesc + reviewDate+reviewtitle;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            if(reviewDate.includes('–')){
                reviewDate = reviewDate.split('–')[1].trim();
            }
            data.push({
                date: reviewDate.trim(),
                title: reviewtitle,
                sourceCollector: 'healthgrades.com',
                sourceURL: request.url,
                uniqueDocKey: uniqueEncodedKey,
                description: reviewDesc,
                ratings: parseInt(overallRatings.replace('Rated ','').replace(' out of 5','')),
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

         let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'healthgrades.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'healthgrades.com',
            "sourceURL": request.url,
            "inputPayload": input,
            checkId: urlMap[request.url].checkId,
            accId: urlMap[request.url].accId
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();