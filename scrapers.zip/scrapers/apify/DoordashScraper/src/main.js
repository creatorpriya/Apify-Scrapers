
// "url": "https://www.doordash.com/store/shalimar-fremont-42463/"

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

const proxyConfiguration = await Actor.createProxyConfiguration({
    groups: ['RESIDENTIAL'],
    countryCode: 'US'
});

async function waitForPageToLoad(urlHostname, page) {
  // Use hostname to get element to load before continuing.
  const selectorToWaitDictionary = {
    "doordash.com": ".sc-8ca4acab-0.XtrxQ", 
};

  console.log("waitForPageToLoad urlHostname", urlHostname);
  //if (selectorToWaitDictionary[urlHostname])
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });
}

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const inputURLs = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    proxyConfiguration,
    // sessionPoolOptions: { maxPoolSize: 1 },
    maxRequestsPerCrawl: 50,
    
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created');

        await waitForPageToLoad('doordash.com', page);

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = []; 

        // let pageContent = $('[type="application/ld+json"]').text();
        // console.log('pagedata=--=', pageContent);
        // let reviewJson = JSON.parse(pageContent);
        // // if(reviewJson !== 'undefined' && reviewJson !== ''){
        //    // console.log('reviewJson.props-==-',reviewJson.props);
        //     reviewJson.review.forEach((item) => { 
        //     const concatedString = 'checkId' + item.reviewBody + item.author + new Date(item.created).toISOString();
        //     const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
        //         data.push({
        //             author: item.author,
        //             sourceCollector: 'doordash.com',
        //             sourceUrl: request.url,
        //             description: item.reviewBody,
        //             ratings: item.reviewRating.ratingValue,
        //             date: new Date(item.created).toISOString(),
        //             "uniqueDocKey": uniqueEncodedKey,
        //             checkId: urlMap[request.url].checkId,
        //             accId: urlMap[request.url].accId
        //         });
        //     });
        // } 
        console.log("reviews..",$('[data-anchor-id="ReviewCard-DoorDash"]'));    
         $('[data-anchor-id="ReviewCard-DoorDash"]').each((i, el) => {
                let reviewDate = $(el).find("div.sc-1ee5c893-3.gwLqwT > span").text().replace("• ", "");
                let reviewauthor = $(el).find("div.InlineChildren__StyledInlineChildren-sc-6r2tfo-0.elDDRc > div > div > span").text();
                let reviewDesc = $(el).find("span.styles__TextElement-sc-3qedjx-0.kpBRmX.sc-7e7d5e8e-2.kPUsIo").text();
                let overallRatings = $(el).find(".InlineChildren__StyledInlineChildren-sc-6r2tfo-0.fBtKYE>svg").length;
             const concatedString = 'checkId' + reviewDesc + reviewDate + reviewauthor;
             const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
             data.push({
                 date: reviewDate,
                 author: reviewauthor,
                 sourceCollector: 'doordash.com',
                 sourceUrl: request.url,
                 description: reviewDesc,
                 ratings: overallRatings,
                 "uniqueDocKey": uniqueEncodedKey,
                 checkId: urlMap[request.url].checkId,
                 accId: urlMap[request.url].accId
             });
         });

        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: [], 
            "inputPayload": input,           
            actorSource: 'doordash.com',
            sourceURL: request.url,
            itemArray: data
        }];

        await Actor.pushData(dataItems);

        const infos = [];

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'doordash.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(startUrls);

console.log('Crawler finished.');

await Actor.exit();