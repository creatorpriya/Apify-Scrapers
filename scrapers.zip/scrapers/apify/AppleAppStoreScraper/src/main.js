import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();
var failedCount = 0;
// const proxyConfiguration = await Actor.createProxyConfiguration({
//     // proxyUrls: [],
//     groups: ['RESIDENTIAL'],
//     countryCode: 'US'
// });

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

const crawler = new PuppeteerCrawler({
    //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 5,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $('.we-customer-review').each((i, el) => {
               let reviewDate = $(el).find("time.we-customer-review__date").text();
               let reviewtitle = $(el).find("h3.we-customer-review__title").text().replace('\n','').replace("  ","").trim();
               let reviewDesc = $(el).find("p").text();
               let reviewAuthor = $(el).find(".we-customer-review__header--user>span:nth-child(1)").text();
               let overallRatings = $(el).find("figure.we-star-rating.we-customer-review__rating.we-star-rating--large").attr("aria-label").split(" ")[0];
                const concatedString = 'checkId' + reviewDesc + reviewDate + reviewtitle + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                author: reviewAuthor.replace(/\n/g,''),
                date: reviewDate,
                title: reviewtitle,
                sourceCollector: 'apps.apple.com',
                sourceUrl: request.url,
                description: reviewDesc,
                ratings: overallRatings,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

         let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'apps.apple.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'apps.apple.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();