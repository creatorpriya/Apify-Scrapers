import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';
import axios from "axios";
const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var failedCount = 0;
const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 5,
    
    // proxyConfiguration,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

       // await waitForPageToLoad('realpatientratings.com', page);

        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        );

        // console.log("pagedata...", pageData);

        const $ = cheerio.load(pageData);
        const data = [];
        //console.log('-==-',$('.results.doctor .review').length);
        let mdId = $('.options [name=mdId]').val()
        let datares = await axios.get(`https://www.realpatientratings.com/reviews/docreviewfilters?sort=new&type=0&mdId=${mdId}&page%5Bnumber%5D=NaN`);
       // console.log('datares--==',datares);
        const $2 = cheerio.load(datares.data);

        //$('.results.doctor .result').append(datares.data);
      //  console.log('-==-',$2('.review').length);
        $2('.review').each((i, el) => { 
            // console.log("review...", [$('.review')]);
            let reviewDate = $(el).find("span.detail.date").text().replace('\n ','');
            let reviewAuthor = $(el).find("span.detail.procedures>a").text();
            let reviewDesc = $(el).find("p.text").text(); 
            let overallRatings = $(el).find("span[itemprop='reviewRating']>meta").attr('content');
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                date: reviewDate.replace(/  /g,'').replace(/\n/g,''),
                sourceCollector: 'realpatientratings.com',
                sourceUrl: request.url.replace(/  /g,''),
                author: reviewAuthor.replace(/  /g,'').replace('\n',''),
                description: reviewDesc.replace(/  /g,'').replace('\n',''),
                ratings: overallRatings,
                uniqueDocKey: uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
                
            });
        });


          let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'realpatientratings.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'realpatientratings.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();
