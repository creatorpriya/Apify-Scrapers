
// https://www.booking.com/hotel/in/the-prime-delhi.en-gb.html?aid=304142&label=gen173nr-1FCAEoggI46AdIM1gEaGyIAQGYAQm4ARfIAQzYAQHoAQH4AQyIAgGoAgO4AqW6waQGwAIB0gIkYjg3YWUyMmMtZDZjNS00YzA5LThkYzQtNDc2MzlmYzBhZWU52AIG4AIB&sid=21a0fef87e0dd02700b7f4ad47d15334&dest_id=-2106102;dest_type=city;dist=0;group_adults=2;group_children=0;hapos=1;hpos=1;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;srepoch=1687182640;srpvid=5240615784c80195;type=total;ucfs=1&#tab-reviews

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

// const proxyConfiguration = await Actor.createProxyConfiguration({  
// });

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);

const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
console.log('click review button');
const selectorToWaitDictionary = {
    "booking.com": "#reviewCardsSection"
};
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });   
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },

    maxRequestsPerCrawl:50,
    
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
        
        const $ = cheerio.load(pageData);
        const data = [];

        // console.log("reviews..",$('#reviewCardsSection > div:nth-child(1) > div > [data-testid="review-card"]'));
        
    $('div:nth-child(1) > div > [data-testid="review-card"]').each((i, el) => {
    const title = $(el).find(`[data-testid="review-title"]`).text();
    const ratings = $(el).find('div.b817090550.b232a3502b > div > div > div > div').text();
    //     console.log('ratings-=--=',ratings);
    const description = $(el).find("[data-testid='review-positive-text'] .a53cbfa6de.b5726afd0b > span").text();
    const datetext = $(el).find(`span[data-testid='review-date']`).text();
    const author = $(el).find('div.a3332d346a.e6208ee469').text();
    // var reviewUrl = '';//$(`[data-test-target="review-title"]`).find(`a`).attr("href");
  //const reviewUrl = reviewUrlData?.split("=")[1];
    // const title = $(el).find('.c-review-block__title').text();
    const concatedString = 'checkId' + title + author + description;
    const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
    
    data.push({
        title: title,
        ratings: ratings.replace(/Scored/g, "").trim(), //parseFloat(ratings)/2,
        date: datetext.replace('Reviewed: ', ''),
        author: author,
        // reviewUrl: ``,
        description: description,
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'booking.com',
        sourceURL: request.url,
        checkId: urlMap[request.url].checkId,
        accId: urlMap[request.url].accId
    });
  });
  
        console.log('final adata-=-',JSON.stringify(data));
        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'booking.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);       
        
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'booking.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();

