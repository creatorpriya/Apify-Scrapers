import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();
/*
const proxyConfiguration = await Actor.createProxyConfiguration({
    // proxyUrls: [],
    groups: ['RESIDENTIAL'],
    countryCode: 'US'
});*/

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
    //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $("div.tw-col-span-full.md\\:tw-col-span-8.lg\\:tw-col-start-5 > div:nth-child(3) > div.tw-pt-0").each((i, el) => {
            let reviewDate = $(el).find(".tw-overflow-x-auto .tw-text-body-xs.tw-text-fg-tertiary").text().trim();
            let reviewAuthor = $(el).find(".tw-text-fg-primary.tw-overflow-hidden.tw-text-ellipsis.tw-whitespace-nowrap").text().trim();
            let reviewDesc = $(el).find("div[data-truncate-review]>div>p.tw-break-words").text();
            let overAllRatings = $(el).find("div[data-merchant-review]>div svg").parent().attr("aria-label").split(" ")[0];
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                author: reviewAuthor,
                date: reviewDate,
                sourceCollector: 'apps.shopify.com',
                sourceURL: request.url,
                description: reviewDesc,
                ratings: parseInt(overAllRatings),
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

        let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            "inputPayload": input,
            actorSource: 'apps.shopify.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'apps.shopify.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();