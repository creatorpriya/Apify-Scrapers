
// https://www.opentable.com/r/la-pizza-and-la-pasta-eataly-silicon-valley-santa-clara

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
//const { startUrls } = input;
const inputURLs = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

// for(let i=0;i<input.startUrls.length;i++){
//     inputURL.push(input.startUrls[i].url);
// }
var failedCount = 0;
const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
    
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $('.afkKaa-4T28-').each((i, el) => {
            let reviewDate = $(el).find("p.iLkEeQbexGs-").text().replace("on ", "");
            let reviewDesc = $(el).find("div._6rFG6U7PA6M- > span").text();
            let reviewAuthor = $(el).find("p._1p30XHjz2rI-.C7Tp-bANpE4-").text();
            let overallRatings = $(el).find('.yEKDnyk-7-g-').attr("aria-label").replace(" stars", "");
            
            
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            var datenum;
            if (reviewDate.includes('Dined')) {
               reviewDate = reviewDate.split('Dined')[1].trim();
            } else if (reviewDate.includes('Dined on')) {
                reviewDate = reviewDate.split('Dined on')[1].trim();
            } 
            if (reviewDate.includes('days ago')) {
                datenum = reviewDate.replace(' days ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('1 day ago') || reviewDate.includes('Yesterday')) {
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('today')) {
                reviewDate = new Date();
            } else if (reviewDate.includes('minutes ago')) {
                datenum = reviewDate.replace(' minutes ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 1000);
            } else if (reviewDate.includes('hours ago')) {
                datenum = reviewDate.replace(' hours ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 60 * 1000);
            } else if (reviewDate.includes('1 week ago')) {
                reviewDate = new Date(Date.now() - 1 * 7 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('weeks ago')) {
                datenum = reviewDate.replace(' weeks ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 7 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('months ago')) {
                datenum = reviewDate.replace(' months ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 30 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('years ago')) {
                datenum = reviewDate.replace(' years ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 365 * 24 * 60 * 60 * 1000);
            }
            data.push({
                date: reviewDate,  
                author: reviewAuthor,
                sourceCollector: 'opentable.com',
                sourceURL: request.url,
                uniqueDocKey: uniqueEncodedKey,
                description: reviewDesc,
                ratings: overallRatings,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId,
            });
        });

         let dataItems = [{
            "status": true,
            "message": "",
            itemArray: data,
            actorSource: 'opentable.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
       // await Actor.exit();

        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'opentable.com',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);

        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();