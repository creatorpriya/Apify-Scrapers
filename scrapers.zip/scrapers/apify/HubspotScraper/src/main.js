import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();


const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
     
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
console.log('inputURLs-==-',inputURLs);
var failedCount = 0;
const crawler = new PuppeteerCrawler({
    //proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];

        $('.p-y-8').each((i, el) => {
               let reviewDate = $(el).find("span.m-top-1").text();
               let reviewtitle = $(el).find("h4").text();
               let reviewDesc = $(el).find("span.private-break-string--hyphenate").text();
               let overallRatings = $(el).find(".display-flex").attr("aria-valuetext").split(" ")[0];
                const concatedString = 'checkId' + reviewDesc + reviewDate + reviewtitle;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            data.push({
                date: reviewDate,
                title: reviewtitle,
                sourceCollector: 'ecosystem.hubspot.com',
                sourceUrl: request.url,
                description: reviewDesc,
                ratings: overallRatings,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });

          let dataItems = [{
            "status": true,
            "message": "",
            "inputPayload": input.startUrls,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'ecosystem.hubspot.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        const infos = [];
        
        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'ecosystem.hubspot.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();