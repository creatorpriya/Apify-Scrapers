
// https://www.grubhub.com/restaurant/parktown-pizza-company--meridian-ave-3039-meridian-ave-san-jose/2302886

import { Actor } from 'apify';
import { PuppeteerCrawler, utils } from "crawlee";
import cheerio from "cheerio";
import puppeteerVanilla from "puppeteer";
import { addExtra } from "puppeteer-extra";
const puppeteer = addExtra(puppeteerVanilla);
import StealthPlugin from "puppeteer-extra-plugin-stealth";
puppeteer.use(StealthPlugin());
await Actor.init();

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}
var errorMessage = '';
async function waitForPageToLoad(urlHostname, page) {
    console.log('click more button');
  const selectorToWaitDictionary = {
    "grubhub.com": '[data-testid="restaurant-about-reviews-sections"]'
    
 };
    
  console.log("waitForPageToLoad urlHostname", urlHostname);
    await page.waitForSelector(selectorToWaitDictionary[urlHostname], {
      visible: false,
      timeout: 0,
    });   
   // await page.click('.yJaSJ');
}
var failedCount = 0;
const crawler = new PuppeteerCrawler({
   // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: false,
            args: ["--no-sandbox"]
            // Other Puppeteer options
        },
    },
    maxRequestsPerCrawl:50,
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Processing ${request}...`);
        console.log('New page created');
         
      
        console.log('Move to review page');
        await page.click('button.sc-hBxehG.cxchPx.restaurantPageNav-tab.active>span.sc-dkrFOg.gSBpp');
        // await page.click('span.yJaSJ'); //[data-name="user-reviews"] 
        await waitForPageToLoad('grubhub.com', page);
            
        console.log('ready to scrap data');
        var pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML

        );
         var totalreview = await page.evaluate(
             () => document.querySelector('.sc-eDvSVe.cqYYWP')
         );
        const $ = cheerio.load(pageData);
        const data = [];

        $('.sc-eDvSVe.cqYYWP').each((i, el) => {
            let reviewDate = $(el).find("div.sc-eDvSVe.sc-jSUZER.bbCHGg.iGedWF > span").text();
            let reviewauthor = $(el).find("h6[data-testid='review-reviewer-name']").text();
            console.log("author names...", reviewauthor);
            let reviewDesc = $(el).find("span.sc-dkrFOg.gGwCpG").text();
            let overallRatings = $(el).find(".sc-eDvSVe.fRZbbP.cbStar--mango > svg").length;
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewauthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            var datenum;

            if (reviewDate.includes('days ago')) {
                datenum = reviewDate.replace(' days ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('A day ago') || reviewDate.includes('Yesterday')) {
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('Today')) {
                reviewDate = new Date();
            } else if (reviewDate.includes('minutes ago')) {
                datenum = reviewDate.replace(' minutes ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 1000);
            } else if (reviewDate.includes('hours ago')) {
                datenum = reviewDate.replace(' hours ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 60 * 1000);
            } else if (reviewDate.includes('1 week ago')) {
                reviewDate = new Date(Date.now() - 1 * 7 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('weeks ago')) {
                datenum = reviewDate.replace(' weeks ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 7 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('months ago')) {
                datenum = reviewDate.replace(' months ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 30 * 24 * 60 * 60 * 1000);
            } else if (reviewDate.includes('years ago')) {
                datenum = reviewDate.replace(' years ago', '');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 365 * 24 * 60 * 60 * 1000);
            }
          
            data.push({
                date: reviewDate,
                author: reviewauthor,
                description: reviewDesc,
                sourceCollector: 'grubhub.com',
                sourceUrl: request.url,
                ratings: overallRatings,
                "uniqueDocKey": uniqueEncodedKey,
                checkId: urlMap[request.url].checkId,
                accId: urlMap[request.url].accId
            });
        });
        
        if(data.length === 0){
            errorMessage = 'Unable to extract data from HTML';
        }else {
            errorMessage = '';
        }
        // Store the results to the default dataset.
        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'grubhub.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);

        // Find a link to the next page and enqueue it if it exists.
        const infos = [];

        if (infos.length === 0) console.log(`${request} is the last page!`);
       
    },

    // This function is called if the page processing failed more than maxRequestRetries+1 times.
    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'grubhub.com.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

// Run the crawler and wait for it to finish.
await crawler.run(inputURLs);

console.log('Crawler finished.');

// Exit successfully
await Actor.exit();