
//  https://www.bbb.org/us/mn/minneapolis/profile/department-stores/target-corporation-0704-1137/customer-reviews

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());
await Actor.init();

var failedCount = 0;

const input = await Actor.getInput();
console.log('Input:');
console.dir(input);
const urlMap = {};
const inputURLs = [];

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}

const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            // Other Puppeteer options
        },
    },

    maxRequestsPerCrawl: 5,

     async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')
        
        let pageData = await page.evaluate(
                () => document.querySelector("*").outerHTML
            );

        const $ = cheerio.load(pageData);
        const data = [];

    $('ul.css-zyn7di.e62xhj40>li.css-n8vred.e1ri33r70').each((i, el) => {
    const ratings = $(el).find('div.css-amhf5.ef0gsym2 > span').text().split(" ")[0];
    console.log('ratings-=--=',ratings);
    const reviewDescription = $(el).find(".css-1epoynv.ef0gsym0 > div").text();
    const reviewDate = $(el).find("div.css-hvqho5.ef0gsym1 > p.bds-body.text-gray-70").text();
    var reviewAuthor = $(el).find('h3.bds-body.text-size-30').text();
    if (reviewAuthor.includes('Review from ')) {
            reviewAuthor = reviewAuthor.split('Review from ')[1].trim();
            }
    const concatedString = 'checkId' + reviewDescription + reviewDate + reviewAuthor;
    const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
    
    data.push({
        // title: title,
        ratings: ratings,
        author: reviewAuthor,
        date: reviewDate,
        description: reviewDescription,
        uniqueDocKey: uniqueEncodedKey,
        sourceCollector: 'bbb.org',
        sourceURL:request.url,
        checkId: urlMap[request.url].checkId,
        accId: urlMap[request.url].accId
    });
  });

  let dataItems = [{
            "status": true,
            "message": "",            
            actorSource: 'bbb.org',
            sourceURL: request.url,
            itemArray: data,
            "inputPayload": input
        }];

        await Actor.pushData(dataItems);

        const infos = [];

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
        console.log(`Request ${request} failed too many times.`);
        if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            actorSource: 'bbb.org',
            "sourceURL": request.url,
            "inputPayload": input
        }];
        await Actor.pushData(dataItems);
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();

       