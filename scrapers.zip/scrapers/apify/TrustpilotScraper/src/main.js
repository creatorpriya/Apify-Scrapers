
// url: "https://www.trustpilot.com/review/salesforce.com"

import { Actor } from 'apify';
import { PuppeteerCrawler } from 'crawlee';
import cheerio from "cheerio";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import puppeteerVanilla from "puppeteer";
import { addExtra } from 'puppeteer-extra';

const puppeteer = addExtra(puppeteerVanilla);
puppeteer.use(StealthPlugin());

await Actor.init();

// const proxyConfiguration = await Actor.createProxyConfiguration({
//     // proxyUrls: [],
//     groups: ['RESIDENTIAL'],
//     countryCode: 'US'
// });
var failedCount = 0;
const input = await Actor.getInput();
console.log('Input: ');
console.dir(input);
const { startUrls } = input;

const inputURLs = [];
const urlMap = {};

for(let i=0;i<input.startUrls.length;i++){
    inputURLs.push(input.startUrls[i].url);
    urlMap[input.startUrls[i].url]= {"checkId":input.startUrls[i].checkId, "accId":input.startUrls[i].accId};
  
}


const crawler = new PuppeteerCrawler({
    // proxyConfiguration,
    launchContext: {
        launchOptions: {
            headless: true,
            args: ["--no-sandbox"]
        },
    },
    maxRequestsPerCrawl: 50,
 
    async requestHandler({ request, page, enqueueLinks }) {
        console.log(`Scraping ${request.url}...`);
        console.log('New page created')

        let pageData = await page.evaluate(
            () => document.querySelector("*").outerHTML
        )

        const $ = cheerio.load(pageData);
        const data = [];
        let errorMessage = '';
        $('article.styles_reviewCard__hcAvl').each((i, el) => {
            let reviewAuthor = $(el).find("span.typography_heading-xxs__QKBS8.typography_appearance-default__AAY17").text();
            let reviewDate = $(el).find(".styles_reviewContentwrapper__zH_9M .styles_reviewHeader__iU9Px .styles_datesWrapper__RCEKH").text().replace("Updated ", "");;
            let reviewtitle = $(el).find("h2").text();
            let reviewDesc = $(el).find("p.typography_color-black__5LYEn").text(); 
            let overallRatings = $(el).find('.star-rating_starRating__4rrcf.star-rating_medium__iN6Ty>img').attr('alt').replace('Rated ','').replace(' out of 5 stars','');
            const concatedString = 'checkId' + reviewDesc + reviewDate + reviewtitle + reviewAuthor;
            const uniqueEncodedKey = Buffer.from(concatedString).toString("base64");
            if(reviewDate.includes('days ago')){
                var datenum = reviewDate.replace(' days ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - datenum * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('A day ago') ||reviewDate.includes('a day ago')){
                reviewDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
            }else if(reviewDate.includes('minutes ago') || reviewDate.includes('A minutes ago')){
                var datenum = reviewDate.replace(' minutes ago','') || reviewDate.replace(' A minutes ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * 1 * datenum * 60 * 1000)
            }else if(reviewDate.includes('hours ago')){
                var datenum = reviewDate.replace(' hours ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * datenum * 60 * 60 * 1000)
            }else if (reviewDate.includes('an hour ago') || reviewDate.includes('An hour ago')) {
                var datenum = reviewDate.replace(' an hour ago','') || reviewDate.replace(' An hour ago','');
                datenum = parseInt(datenum);
                reviewDate = new Date(Date.now() - 1 * 60 * 60 * 1000);
                }
            data.push({
                author: reviewAuthor,
                date: reviewDate,
                sourceCollector: 'trustpilot.com',
                sourceUrl: request.url,
                title: reviewtitle,
                description: reviewDesc,
                ratings: overallRatings,
                uniqueDocKey: uniqueEncodedKey,
        checkId: urlMap[request.url].checkId,
        accId: urlMap[request.url].accId
                
            });
        });

        if(data.length === 0){
            errorMessage = "Unable to extract data from HTML";
        }else {
            errorMessage = "";
        }

        let dataItems = [{
            "status": true,
            "message": errorMessage,
            itemArray: data,
            "inputPayload": input,
            actorSource: 'trustpilot.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
            


        const infos = [];
        // await enqueueLinks({
        //     selector: '',
        // })

        if ( infos.length === 0 ) console.log(`${request} is the last page.`)
    },

    async failedRequestHandler({ request }) {
         console.log(`Request ${request} failed too many times.`);
         if(failedCount > 2){
            let dataItems = [{
            "status": false,
            "message": "403",
            itemArray: [],
            "inputPayload": input,
            actorSource: 'trustpilot.com',
            "sourceURL": request.url
        }];
        await Actor.pushData(dataItems);
            
        }
           

            failedCount++;
    },
});

await crawler.run(inputURLs);

console.log('Crawler finished.');

await Actor.exit();